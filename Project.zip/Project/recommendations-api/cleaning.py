# import pandas as pd
#
# # Load the CSV file
# df = pd.read_csv('updated_file.csv')
#
# # List all columns to check their names
# print("Available columns:", df.columns.tolist())
#
# # Ensure correct column names
# required_columns = ['articleType', 'brand', 'subCategory', 'baseColour', 'season', 'usage']
#
# # Check if all required columns are present
# missing_columns = [col for col in required_columns if col not in df.columns]
#
# if not missing_columns:
#     # Create a template for product descriptions
#     template = (
#         "Introducing the {articleType} from {brand}. This product belongs to the {subCategory} "
#         "category and comes in a beautiful {baseColour} color. Ideal for the {season} season, "
#         "it's perfect for {usage}. Get yours today!"
#     )
#
#     # Generate descriptions using the correct column names
#     df['description'] = df.apply(
#         lambda row: template.format(
#             articleType=row['articleType'],
#             brand=row['brand'],
#             subCategory=row['subCategory'],
#             baseColour=row['baseColour'],  # Corrected the column name
#             season=row['season'],
#             usage=row['usage']
#         ),
#         axis=1
#     )
#
#     # Save the updated DataFrame to a new CSV file
#     df.to_csv('updated_file.csv', index=False)
#
#     print("Descriptions generated and saved to 'updated_file.csv'")
# else:
#     print("Missing columns:", missing_columns)

import pandas as pd

df = pd.read_csv('updated_file.csv')  # Replace 'your_file.csv' with your actual file name

# Dictionary mapping categories to MongoDB Object IDs
category_to_object_id = {
    'Footwear': '664cc53b1e2ba7d5ce93592a',
    'Apparel': '664cc54f1e2ba7d5ce935932',
    'Accessories': '664cc5461e2ba7d5ce93592e'
}

# Replace categories with corresponding Object IDs
df['category'] = df['category'].map(category_to_object_id)

# Save to CSV
df.to_csv('output.csv',index=False)