import pymongo
import pickle
import os

# Connect to MongoDB
mongo_url = "mongodb://localhost:27017/huxnStore"
client = pymongo.MongoClient(mongo_url)
db = client['huxnStore']  # Change to your correct database name
products_collection = db['products']  # Change to your correct collection name

# Load embeddings and filenames
feature_list = pickle.load(open('embeddings.pkl', 'rb'))
filenames = pickle.load(open('filenames.pkl', 'rb'))

print(filenames)

# Normalize the filenames to match the product filenames
normalized_filenames = [os.path.basename(file) for file in filenames]

# Iterate over filenames and embeddings, then store them in MongoDB
for filename, embedding in zip(normalized_filenames, feature_list):
    # Find the product with the matching filename
    product = products_collection.find_one({'filename': filename})

    if product:
        # Update the product document with the embedding
        products_collection.update_one(
            {'_id': product['_id']},
            {'$set': {'embedding': embedding.tolist()}}  # MongoDB does not support direct numpy arrays, convert to list
        )
        print(f"Updated product with filename {filename} with embedding.")
    else:
        print(f"Product with filename {filename} not found in the collection.")

print("Finished updating embeddings in MongoDB.")
