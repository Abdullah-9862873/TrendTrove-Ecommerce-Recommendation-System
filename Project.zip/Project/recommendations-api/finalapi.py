from flask import Flask, request, jsonify
import numpy as np
from flask_cors import CORS 
#flask used to run frontend with backend
from sklearn.neighbors import NearestNeighbors
#ML algorithm used for recommendation system
from pymongo import MongoClient
#to connect database with MongoDB with python
from bson import ObjectId
#to convert datatypeS
import traceback
#exception handling

# Initialize Flask app
app = Flask(__name__)
CORS(app, resources={r"/recommend": {"origins": "http://localhost:5173"}})
# Connect to MongoDB
mongo_uri = "mongodb://localhost:27017/huxnStore"
client = MongoClient(mongo_uri)
db = client.huxnStore  # Connect to 'ecommerce (huxnStore)' database
products_collection = db.products  # Access 'products' collection

# Initialize the Nearest Neighbors for recommendations
neighbors = NearestNeighbors(n_neighbors=5, algorithm='brute', metric='euclidean')

# Fetch embeddings from MongoDB
def fetch_embeddings():
    products = list(products_collection.find())
    embeddings = []
    filenames = []

    for product in products:
        if "embedding" in product and "filename" in product:
            embeddings.append(np.array(product["embedding"]))
            filenames.append(product["filename"])

    return np.array(embeddings), filenames

# Fetch precomputed embeddings and filenames
feature_list, filenames = fetch_embeddings()

# Fit the Nearest Neighbors model with the embeddings
neighbors.fit(feature_list)

# Function to convert ObjectId fields to strings
def convert_object_id_to_str(document):
    for key, value in document.items():
        if isinstance(value, ObjectId):
            document[key] = str(value)
        elif isinstance(value, dict):
            convert_object_id_to_str(value)
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    convert_object_id_to_str(item)


@app.route('/recommend', methods=['POST'])
def recommend_by_product_id():
    if 'product_id' not in request.json:
        return jsonify({"error": "No product_id provided"}), 400 #for testing

    product_id = request.json['product_id']

    try:
        # Fetch the product from MongoDB using the provided product ID
        product = products_collection.find_one({"_id": ObjectId(product_id)})

        if not product:
            return jsonify({"error": "Product not found with the given ID"}), 404

        if "embedding" not in product or "filename" not in product:
            return jsonify({"error": "Product does not have embedding or filename"}), 404

        # Get the embedding for this product
        product_embedding = np.array(product["embedding"])

        # Find similar products using Nearest Neighbors
        distances, indices = neighbors.kneighbors([product_embedding])

        # Get the filenames for the recommended products
        recommended_files = [filenames[idx] for idx in indices[0]]

        # Fetch the recommended products from MongoDB
        recommended_products = list(
            products_collection.find({"filename": {"$in": recommended_files}})
        )

        # Convert ObjectId to string for JSON compatibility
        for product in recommended_products:
            convert_object_id_to_str(product)

        # Return the recommended products in JSON format
        # return jsonify({"recommended_products": []})
        return jsonify({"recommended_products": recommended_products})


    except Exception as e:
        error_trace = traceback.format_exc()
        return jsonify({"error": f"An error occurred: {error_trace}"}), 500


# Start the Flask app
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
