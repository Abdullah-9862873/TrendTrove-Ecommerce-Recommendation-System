import pandas as pd

df = pd.read_csv('productdata.csv')  # Replace 'your_file.csv' with your actual file name

# Dictionary mapping categories to MongoDB Object IDs
category_to_object_id = {
    'Footwear': '66362bb54727ae1929a17c20',
    'Apparel': '66362bbe4727ae1929a17c24',
    'Accessories': '66362bc74727ae1929a17c28'
}

# Replace categories with corresponding Object IDs
df['category'] = df['category'].map(category_to_object_id)

# Save to CSV
df.to_csv('output.csv', index=False)